import React from "react";

function Header() {
  return (
    <header className="header">
      <h1>My Personal Portfolio</h1>
      <p>Welcome to my portfolio website</p>
    </header>
  );
}

export default Header;